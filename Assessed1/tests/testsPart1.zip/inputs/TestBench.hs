{-# LANGUAGE Unsafe #-}
{-# LANGUAGE CPP #-}
module TestBench where

import Prelude hiding (catch)
import Control.Exception
import Control.Monad
import System.Timeout
import Test.QuickCheck
import Test.QuickCheck.Test (isSuccess, output)
import Data.IORef

-- Data follows.

import safe Assessed1Part1 (
    decode, decompress, decompress', charlength, memSize, Tree(..), Bit(..), tabulate
    )
import TestHelpers


-- This file was automatically generated
-- by GenerateTests.hs
-- on 2016-11-02 15:18:12.642022108 UTC

main :: IO ()
main = do
    points <- newIORef 0

    putStrLn "Test 1: decode (7 points)"
    res_1_1 <- unitTests "test_decode" test_decode test_decode_1_1_in test_decode_1_1_out
    addPoints points $ defaultMarker "decode" 7 [res_1_1]
    putStrLn ""

    putStrLn "Test 2: decompress (7 points)"
    res_2_1 <- unitTests "test_decompress" test_decompress test_decompress_2_1_in test_decompress_2_1_out
    addPoints points $ defaultMarker "decompress" 7 [res_2_1]
    putStrLn ""

    putStrLn "Test 3: decompress' (4 points)"
    res_3_1 <- unitTests "test_decompress'_1" test_decompress'_1 test_decompress'_1_3_1_in test_decompress'_1_3_1_out
    res_3_2 <- unitTests "test_decompress'_2" test_decompress'_2 test_decompress'_2_3_2_in test_decompress'_2_3_2_out
    addPoints points $ defaultMarker "decompress'" 4 [res_3_1, res_3_2]
    putStrLn ""

    putStrLn "Test 4: tabulate (7 points)"
    res_4_1 <- unitTests "test_tabulate" test_tabulate test_tabulate_4_1_in test_tabulate_4_1_out
    addPoints points $ defaultMarker "tabulate" 7 [res_4_1]
    putStrLn ""
    putStrLn "Total possible points for this set: 25"
    putStrLn "Expected number of points for your solution: "
    print =<< readIORef points
    putStrLn "Your expected mark is: "
    print . (/ 0.25) . fromIntegral =<< readIORef points

-- START automatically generated inputs/outputs --


-- Inputs and correct outputs for test_decode
test_decode_1_1_in = [
    -- test_decode_1_1_in !! 0
    ()
  ]
test_decode_1_1_out = [
    -- test_decode_1_1_out !! 0
    True
  ]

-- Inputs and correct outputs for test_decompress
test_decompress_2_1_in = [
    -- test_decompress_2_1_in !! 0
    ()
  ]
test_decompress_2_1_out = [
    -- test_decompress_2_1_out !! 0
    True
  ]

-- Inputs and correct outputs for test_decompress'_1
test_decompress'_1_3_1_in = [
    -- test_decompress'_1_3_1_in !! 0
    ()
  ]
test_decompress'_1_3_1_out = [
    -- test_decompress'_1_3_1_out !! 0
    True
  ]

-- Inputs and correct outputs for test_decompress'_2
test_decompress'_2_3_2_in = [
    -- test_decompress'_2_3_2_in !! 0
    ()
  ]
test_decompress'_2_3_2_out = [
    -- test_decompress'_2_3_2_out !! 0
    True
  ]

-- Inputs and correct outputs for test_tabulate
test_tabulate_4_1_in = [
    -- test_tabulate_4_1_in !! 0
    ()
  ]
test_tabulate_4_1_out = [
    -- test_tabulate_4_1_out !! 0
    True
  ]


-- Common part follows.

timeOutTime :: Num a => a
timeOutTime = 10^6 * 60 -- One minute

unitTest :: (Eq b, Show a, Show b) => String -> (a -> b) -> a -> b -> IO Bool
unitTest name f x spec = do
  -- Using QuickCheck here for convenience (since it catches exceptions and
  -- timeouts for us)
  result <- quickCheckWithResult stdArgs {chatty = False}
          $ timeoutProp (f x == spec)

  case result of
    Failure {} -> do
      putStrLn "*** Failed!"
      putStrLn $ "Input: " ++ show x
      catch (timeoutOutput $ putStrLn $ "Output: " ++ show (f x))
            (\msg -> putStrLn $ "Exception: " ++ show (msg :: SomeException))
      putStrLn $ "Expected output: " ++ show spec
      return False

    GaveUp {} -> do
      putStrLn "Gave up."
      return False
    _ -> return True

  where
    timeoutOutput :: IO a -> IO a
    timeoutOutput action = do
        res <- timeout timeOutTime action

        case res of
            Just result -> return result
            Nothing     -> error "<<timeout>>"

unitTests :: (Eq b, Show a, Show b) => String -> (a -> b) -> [a] -> [b] -> IO Float
unitTests name f inputs spec = do
  putStr $ "  [testing] " ++ name ++ "... "
  res <- run $ zipWith (unitTest name f) inputs spec

  when (res == 1) $ putStrLn "ok."

  return res

  where
    run [] = return 1
    run (x:xs) = do
      r <- x
      if r then run xs
      else return 0

quickTest :: Testable prop => String -> prop -> IO Bool
quickTest name = quickTestWith name stdArgs

quickTestWith :: Testable prop => String -> Args -> prop -> IO Bool
quickTestWith name args0 prop = do
  putStr $ "  [checking] " ++ name ++ "... "
  let args = args0 {chatty = False}
  result <- quickCheckWithResult args
          $ timeoutProp prop

  if not (isSuccess result)
    then do
        putStrLn "eh, nope."
        putStrLn (output result)
        return False
    else do
        putStrLn "ok."
        return True

timeoutProp :: Testable prop => prop -> Property
timeoutProp = within timeOutTime

-- Gives full mark only if all parts of the exercise succeded. Otherwise gives
-- 0 points.
defaultMarker :: String -> Int -> [Float] -> Int
defaultMarker exerciseName points bs
    -- There is only a single floating-point representation for 1, so this is safe.
    | all (==1) bs    = points
    | otherwise = 0

addPoints :: IORef Int -> Int -> IO ()
addPoints var points = putStrLn ("\nPoints given: " ++ show points) >> modifyIORef' var (+ points)
